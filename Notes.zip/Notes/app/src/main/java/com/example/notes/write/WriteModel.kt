package com.example.notes.write

import android.content.Context
import android.text.Editable
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.notes.database.NoteDatabase
import com.example.notes.database.Notes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WriteModel: ViewModel() {

    fun checkString(title: Editable?, desc: Editable?): Boolean {
        if(title.toString().trim().isNotBlank() && desc.toString().trim().isNotBlank()){
            return true
        }else{
            return false
        }
    }

    fun save(applicationContext: Context, title: Editable?, desc: Editable?){
        val database=NoteDatabase.getInstance(applicationContext)
        val noteTitle = title.toString().trim()
        val noteDesc = desc.toString().trim()
        val dateFormat = SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date())
        val created = dateFormat.format(Date())
        if (noteTitle.trim().isNotBlank() || noteDesc.trim().isNotBlank()) {
            val note = Notes(0, noteTitle, noteDesc,created)
            viewModelScope.launch {
                withContext(Dispatchers.IO) {
                    try {
                        database?.notedatabasedao()?.insert(note)
                    } catch (e: Exception) {
                        Log.i("tag", "Error inserting note")
                    }
                }
            }

        }
    }

    fun update(requireContext: Context, id: Long, title: String, desc: String) {
        var database=NoteDatabase.getInstance(requireContext)
        val noteTitle = title.toString().trim()
        val noteDesc = desc.toString().trim()
        val dateFormat = SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date())
        val created = dateFormat.format(Date())
        //val created=SimpleDateFormat("EEE ,dd MM").format(Date())
        if (noteTitle.trim().isNotBlank() || noteDesc.trim().isNotBlank()) {
            val note = Notes(id, noteTitle, noteDesc,created)
            viewModelScope.launch {
                withContext(Dispatchers.IO) {
                    try {
                        database?.notedatabasedao()?.update(note)
                    } catch (e: Exception) {
                        Log.i("tag", "Error inserting note")
                    }
                }
            }
        }

    }

    fun delete(applicationContext: Context?, arg: WriteNotesFragmentArgs) {
        val database=NoteDatabase.getInstance(applicationContext!!)
        var notes=Notes(arg.id,arg.title,arg.desc,arg.created)
        viewModelScope.launch {
            withContext(Dispatchers.IO){
                try {
                    database?.notedatabasedao()?.delete(notes)
                }catch (e:Exception){
                    Log.i("tag", "Error Deleting note")
                }
            }
        }

    }
}

