package com.example.notes.write
//
//import android.content.Context
//import androidx.lifecycle.ViewModel
//import androidx.lifecycle.ViewModelProvider
//import com.example.notes.database.NoteDatabase
//
//class WriteModelFactory(private val context: Context) : ViewModelProvider.Factory {
//    override fun <T : ViewModel> create(modelClass: Class<T>): T {
//        if (modelClass.isAssignableFrom(WriteModel::class.java)) {
//            val database = NoteDatabase.getInstance(context)
//            @Suppress("UNCHECKED_CAST")
//            return WriteModel(database!!) as T
//        }
//        throw IllegalArgumentException("Unknown ViewModel class")
//    }
//}
