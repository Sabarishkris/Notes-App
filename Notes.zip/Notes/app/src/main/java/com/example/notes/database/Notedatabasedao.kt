package com.example.notes.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface Notedatabasedao {
    @Insert
    fun insert(notes: Notes)
    @Update
    fun update(notes: Notes)
    @Delete
    fun delete(notes: Notes)
    @Query("select * from note_database")
    fun getNotes():List<Notes>
    @Query("delete from note_database")
    fun deleteAll()
}