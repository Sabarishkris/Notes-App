package com.example.notes.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "note_database")
data class Notes(

    @ColumnInfo(name = "notes_id")
    @PrimaryKey(autoGenerate = true)
    var notesId:Long,
    @ColumnInfo(name = "title")
var title:String,
    @ColumnInfo(name = "description")
    var description:String,
    @ColumnInfo(name = "Created")
    var created:String
)
