package com.example.notes.note

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.notes.database.NoteDatabase
import com.example.notes.database.Notes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NoteModel : ViewModel(), NoteClickListener {
    var notedId: Long = -1
    var title: String = "title"
    var desc: String = "desc"
    var created: String = "created"
    private lateinit var RECYCLERVIEW: RecyclerView

    private lateinit var adapter: NoteAdapter
    private lateinit var list: List<Notes>
    fun deleteAllNotes(applicationContext: Context, recyclerView: RecyclerView, ) {
        var database = NoteDatabase.getInstance(applicationContext)
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    database?.notedatabasedao()?.deleteAll()
                    withContext(Dispatchers.Main){
                        adapter.clearItem()
                    }

                } catch (e: Exception) {
                    Log.i("delete", "Delete failed")
                }
            }
        }
    }



    fun setdata(recyclerView: RecyclerView, applicationContext: Context?) {
            var database = NoteDatabase.getInstance(applicationContext!!)
            RECYCLERVIEW = recyclerView
            viewModelScope.launch {
                withContext(Dispatchers.IO) {
                    try {
                        list = database?.notedatabasedao()?.getNotes()!!
                        adapter = NoteAdapter(list!!, this@NoteModel)
                        recyclerView.adapter = adapter
                        adapter.notifyDataSetChanged()
                    } catch (e: Exception) {
                        Log.i("get", "Error get note")
                    }
                }
            }
        }

        override fun itemClicked(position: Int) {
            Log.d("Tag", "Item on click${list[position]}")
            var notes: Notes = list[position]
            notedId = notes.notesId
            title = notes.title
            desc = notes.description
            created = notes.created
            val action =
                NoteDirections.actionNoteToWriteNotesFragment(notedId, title, desc, created)
            RECYCLERVIEW.findNavController().navigate(action)
        }


}