package com.example.notes.write

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.notes.R
import com.example.notes.databinding.FragmentWriteNotesBinding

class WriteNotesFragment : Fragment() {
    private lateinit var binding: FragmentWriteNotesBinding
    private lateinit var writeModel: WriteModel
    var flag=0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout using DataBindingUtil
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_write_notes, container, false)

        // Initialize the ViewModel
        //val factory = WriteModelFactory(requireContext().applicationContext)
        writeModel = ViewModelProvider(this).get(WriteModel::class.java)
var arg=WriteNotesFragmentArgs.fromBundle(requireArguments())
        var id=arg.id
        var title=arg.title
        var desc=arg.desc
        var created=arg.created
        if(title.trim().isNotBlank() && desc.trim().isNotBlank()){
            binding.title.setText(title)
            binding.desc.setText(desc)
            flag=1
        }

        binding.submit.setOnClickListener {
            if (flag == 1) {

                writeModel.update(
                    requireContext(),
                    id,
                    binding.title.text.toString(),
                    binding.desc.text.toString()

                )

                Toast.makeText(context, "Note update Successfully", Toast.LENGTH_SHORT).show()
                binding.title.text.clear()
                binding.desc.text.clear()
                flag = 0
            } else {
                val title = binding.title.text
                val desc = binding.desc.text

                if (writeModel.checkString(title, desc)) {
                    writeModel.save(requireContext().applicationContext, title, desc)
                    Toast.makeText(context, "Notes Saved", Toast.LENGTH_SHORT).show()
                    binding.title.text.clear()
                    binding.desc.text.clear()
                } else {
                    Toast.makeText(
                        context,
                        "Please enter notes title and description",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
        binding.delete.setOnClickListener {
            val title = binding.title.text
            val desc = binding.desc.text
            if (writeModel.checkString(title, desc) && flag==1) {
                flag=0
                writeModel.delete(requireContext().applicationContext,arg)
                Toast.makeText(
                    context,
                    "Note deleted successfully",
                    Toast.LENGTH_SHORT
                ).show()
                binding.title.text.clear()
                binding.desc.text.clear()
            }else if(writeModel.checkString(title, desc)){
                binding.title.text.clear()
                binding.desc.text.clear()
            } else{
                Toast.makeText(
                    context,
                    "Please enter notes title and description",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        return binding.root
    }
}
