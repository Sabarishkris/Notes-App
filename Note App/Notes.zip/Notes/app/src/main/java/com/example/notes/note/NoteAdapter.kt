package com.example.notes.note

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.notes.R
import com.example.notes.database.Notes

class NoteAdapter(var list: List<Notes>,private val noteClickeListener: NoteClickListener) : RecyclerView.Adapter<NoteAdapter.ViewHolder>()  {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.notes_view, parent, false)
        return ViewHolder(view,noteClickeListener)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var notes: Notes = list[position]
        holder.title.text = notes.title
        holder.desc.text = notes.description
        holder.created.text = notes.created
       
    }

    class ViewHolder(view: View,noteClickListener: NoteClickListener) : RecyclerView.ViewHolder(view) {
        init {
            itemView.setOnClickListener{noteClickListener.itemClicked(adapterPosition)}
        }
        var title: TextView = view.findViewById(R.id.title)
        var desc: TextView = view.findViewById(R.id.desc)
        var created: TextView = view.findViewById(R.id.created)
    }
     fun clearItem() {
        list= emptyList()
        notifyDataSetChanged()
    }
}
interface NoteClickListener {
    fun itemClicked(position:Int)
}