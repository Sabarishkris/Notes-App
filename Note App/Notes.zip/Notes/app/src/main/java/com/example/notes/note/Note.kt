package com.example.notes.note

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.notes.R
import com.example.notes.databinding.FragmentNoteBinding

class Note : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var noteModel: NoteModel
    private lateinit var binding:FragmentNoteBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_note, container, false)
        recyclerView=binding.recyclerView
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager=LinearLayoutManager(requireContext().applicationContext)
       noteModel=ViewModelProvider(this).get(NoteModel::class.java)
        noteModel.setdata(recyclerView,requireContext().applicationContext)

        binding.floatingButton.setOnClickListener {
            Toast.makeText(context,"Button clicked",Toast.LENGTH_SHORT).show()
            view?.findNavController()?.navigate(NoteDirections.actionNoteToWriteNotesFragment(0,"","",""))
        }
        setHasOptionsMenu(true)
        return binding.root
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
       inflater.inflate(R.menu.delete,menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.delete_all -> { showDialog()
            Toast.makeText(context,"All notes are deleted",Toast.LENGTH_SHORT).show()}
        }

        return super.onOptionsItemSelected(item)
    }

    private fun showDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete")
            .setMessage("Do you want to delete all notes?")
            .setPositiveButton("Yes") { _, _ ->
                noteModel.deleteAllNotes(requireContext(), recyclerView)
            }
            .setNeutralButton("No", null)
            .show()
    }

}